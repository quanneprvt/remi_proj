// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from "next";
import { Response } from "../../app/interfaces";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<Response>
) {
  if (req.headers["authorization"]) {
    switch (req.method) {
      case "POST":
        {
          const { item, price } = JSON.parse(req.body);
          const data = await fetch(
            `${process.env.NEXT_PUBLIC_SERVER_URL}/api/bids/`,
            {
              method: "POST",
              headers: new Headers({
                "content-type": "application/json",
                authorization: req.headers["authorization"],
              }),
              body: JSON.stringify({ item, price }),
            }
          );
          const result = await data.json();
          if (result.status === "TOKEN_INVALID") {
            res.status(401).json({ message: "Unauthorized" });
          } else res.status(200).json({ data: result.data.bid });
        }
        break;

      case "GET":
        {
          const data = await fetch(
            `${process.env.NEXT_PUBLIC_SERVER_URL}/api/bids/`,
            {
              method: "GET",
              headers: new Headers({
                "content-type": "application/json",
                authorization: req.headers["authorization"],
              }),
            }
          );
          const result = await data.json();
          if (result.status === "TOKEN_INVALID") {
            res.status(401).json({ message: "Unauthorized" });
          } else res.status(200).json({ data: result.data.bids });
        }
        break;
    }
  } else {
    res.status(400).json({ data: { message: "no token found" } });
  }
}
