import { useCallback, useEffect, useState } from "react";
import BaseLayout from "@/app/baseLayout";
import { Bid, Item } from "@/app/interfaces";
import useApi from "@/hooks/useApi";
import { useSessionProvider } from "@/providers/useSessionProvider";
import { Button, Card, Input, List, Modal } from "antd";

const MyBid = () => {
  const [bids, setBids] = useState<Bid[]>([]);
  const { getMethod, postMethod } = useApi("/api/bids");
  const session = useSessionProvider();
  const [bidModal, setBidModal] = useState<boolean>(false);
  const [selectedBidItem, setSelectedBidItem] = useState<Item>();
  const [bidPrice, setBidPrice] = useState<number>(0);

  useEffect(() => {
    async function fetchItems() {
      const result = await getMethod<Bid[]>();
      if (result?.data) {
        setBids(result.data);
        session.setSession((ses) => ({ ...ses, myBids: result.data }));
      }
    }
    if (session.access_token) fetchItems();
  }, [getMethod, session, session.access_token]);

  const selectBidItem = useCallback((item: Item) => {
    setSelectedBidItem(item);
    setBidModal(true);
  }, []);

  const deselectBidItem = useCallback(() => {
    setSelectedBidItem(undefined);
    setBidModal(false);
    setBidPrice(0);
  }, []);

  const updateBidsSession = useCallback(
    (bid: Bid) => {
      const bidItemIndex = session.myBids?.findIndex(
        (bid) => selectedBidItem?._id === bid.item._id
      );
      if (bidItemIndex !== undefined && bidItemIndex !== -1) {
        session.setSession((ses) => {
          const temp = [...(ses.myBids || [])];
          temp[bidItemIndex] = bid;
          return {
            ...ses,
            money:
              ses.money - (bidPrice - (ses.myBids?.[bidItemIndex].price || 0)),
            myBids: temp,
          };
        });
      } else {
        session.setSession((ses) => ({
          ...ses,
          money: ses.money - bidPrice,
          myBids: [...(ses.myBids || []), bid],
        }));
      }
    },
    [bidPrice, selectedBidItem?._id, session]
  );

  const onBidItem = useCallback(async () => {
    if (
      selectedBidItem?.price !== undefined &&
      bidPrice < selectedBidItem?.price
    ) {
      alert("Bid price cannot lower than current price");
      return;
    }
    const result = await postMethod<Bid>({
      body: { item: selectedBidItem?._id, price: bidPrice },
    });
    result &&
      setBids((itms) => {
        const itemIndex = itms.findIndex(
          (itm) => itm._id === result?.data.item._id
        );
        const temp = [...itms];
        temp[itemIndex] = result?.data;
        return temp;
      });
    result?.data && updateBidsSession(result?.data);
    deselectBidItem();
  }, [
    bidPrice,
    deselectBidItem,
    postMethod,
    selectedBidItem?._id,
    selectedBidItem?.price,
    updateBidsSession,
  ]);

  return (
    <BaseLayout>
      <div>There are currently {bids.length} bid(s)</div>
      <List
        dataSource={bids}
        renderItem={(bid) => (
          <List.Item style={{ paddingLeft: 0 }}>
            <Card
              key={bid._id}
              title={bid.item?.name}
              style={{ width: "100%" }}
              actions={[
                <Button
                  key="bid"
                  type="primary"
                  style={{ width: "50%" }}
                  onClick={() => selectBidItem(bid.item)}
                >
                  Bid
                </Button>,
              ]}
            >
              <p>Item Price: {bid.item?.name}</p>
              <p>Bid Price: {bid?.price || 0}</p>
            </Card>
          </List.Item>
        )}
      />
      <Modal
        title={`Bid for item ${selectedBidItem?.name}`}
        open={bidModal}
        onOk={onBidItem}
        onCancel={deselectBidItem}
        destroyOnClose
      >
        Price:
        <Input
          onChange={(e) => setBidPrice(parseFloat(e.target.value))}
          type={"number"}
        ></Input>
      </Modal>
    </BaseLayout>
  );
};

export default MyBid;
