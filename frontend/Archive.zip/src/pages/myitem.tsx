import { useCallback, useEffect, useState } from "react";
import BaseLayout from "@/app/baseLayout";
import ItemModal from "@/components/Modals/ItemModal";
import { Button, Card, List, Select } from "antd";
import useApi from "@/hooks/useApi";
import { useSessionProvider } from "@/providers/useSessionProvider";
import { Item, ItemStatus } from "@/app/interfaces";

const Bid = () => {
  const [items, setItems] = useState<Item[]>([]);
  const [openCreateItemModal, setOpenCreateItemModal] = useState(false);
  const { postMethod, getMethod, putMethod } = useApi("/api/items");
  const session = useSessionProvider();

  useEffect(() => {
    async function fetchItems() {
      const result = await getMethod<Item[]>();
      result?.data && setItems(result.data);
    }
    if (session.access_token) fetchItems();
  }, [getMethod, session.access_token]);

  const onCreateItem = useCallback(
    async (data: unknown) => {
      const result = await postMethod<Item>({
        body: { ...(data as object) },
      });
      result && setItems((itms) => [...itms, result.data]);
      setOpenCreateItemModal(false);
    },
    [postMethod]
  );

  const onUpdateStatus = useCallback(
    async (data: Partial<Item>) => {
      const item = items.find((itm) => itm._id === data._id);
      await putMethod<Item>({
        body: { ...(item as object), status: data.status },
      });
      setItems((itms) => {
        const itemIndex = items.findIndex((itm) => itm._id === data._id);
        const temp = [...itms];
        temp[itemIndex].status = data.status as ItemStatus;
        return temp;
      });
      setOpenCreateItemModal(false);
    },
    [items, putMethod]
  );

  return (
    <BaseLayout>
      <List
        dataSource={items}
        renderItem={(item) => (
          <List.Item style={{ paddingLeft: 0 }}>
            <Card key={item._id} title={item.name} style={{ width: "100%" }}>
              <p>Price: {item.price}</p>
              <Select
                defaultValue={item.status}
                options={Object.keys(ItemStatus).map((status) => {
                  return {
                    label: status,
                    value: ItemStatus[status as ItemStatus],
                  };
                })}
                onChange={(value) =>
                  onUpdateStatus({ _id: item._id, status: value })
                }
              />
            </Card>
          </List.Item>
        )}
      />
      <Button type="primary" onClick={() => setOpenCreateItemModal(true)}>
        Create Item To Bid
      </Button>
      <ItemModal
        open={openCreateItemModal}
        onConfirm={onCreateItem}
        onClose={() => setOpenCreateItemModal(false)}
      />
    </BaseLayout>
  );
};

export default Bid;
