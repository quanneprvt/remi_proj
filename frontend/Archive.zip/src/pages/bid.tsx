import { useCallback, useEffect, useState } from "react";
import BaseLayout from "@/app/baseLayout";
import { Bid, Item, SocketMessage } from "@/app/interfaces";
import useApi from "@/hooks/useApi";
import { useSessionProvider } from "@/providers/useSessionProvider";
import Link from "next/link";
import { Button, Card, Input, List, Modal } from "antd";
import ItemCard from "@/components/ItemCard/ItemCard";

const Bid = () => {
  const [items, setItems] = useState<Item[]>([]);
  const { getMethod } = useApi("/api/items/bid");
  const { postMethod } = useApi("/api/bids");
  const session = useSessionProvider();
  const [bidModal, setBidModal] = useState<boolean>(false);
  const [selectedBidItem, setSelectedBidItem] = useState<Item>();
  const [bidPrice, setBidPrice] = useState<number>(0);

  const updateBidForItem = useCallback(
    ({ item, bid }: { item?: Item; bid?: Bid }) => {
      setItems((itms) => {
        const temp = [...itms];
        if (item) {
          const itemIndex = itms.findIndex((itm) => itm._id === item._id);
          if (itemIndex !== -1) {
            temp[itemIndex].currentBid = bid;
          } else {
            item && temp.unshift(item);
          }
          return temp;
        } else return temp;
      });
    },
    []
  );

  useEffect(() => {
    async function fetchItems() {
      const result = await getMethod<Item[]>({
        ignoreAuth: true,
        ignoreRefresh: true,
      });
      result?.data && !(result.data as any)?.messages && setItems(result.data);
    }
    fetchItems();
  }, [getMethod, session.access_token]);

  useEffect(() => {
    const socket = session.socket;
    socket?.on("BID_UPDATE", (message) => {
      const data = JSON.parse(message) as SocketMessage;
      updateBidForItem(data);
    });
    return () => {
      socket?.off("BID_UPDATE");
    };
  }, [session.socket, updateBidForItem]);

  const selectBidItem = useCallback((item: Item) => {
    setSelectedBidItem(item);
    setBidModal(true);
  }, []);

  const deselectBidItem = useCallback(() => {
    setSelectedBidItem(undefined);
    setBidModal(false);
    setBidPrice(0);
  }, []);

  const updateBidsSession = useCallback(
    (bid: Bid) => {
      const bidItemIndex = session.myBids?.findIndex(
        (bid) => selectedBidItem?._id === bid.item._id
      );
      if (bidItemIndex !== undefined && bidItemIndex >= 0) {
        session.setSession((ses) => {
          const temp = [...(ses.myBids || [])];
          temp[bidItemIndex] = bid;
          return {
            ...ses,
            money:
              ses.money - (bidPrice - (ses.myBids?.[bidItemIndex].price || 0)),
            myBids: temp,
          };
        });
      } else {
        session.setSession((ses) => ({
          ...ses,
          money: ses.money - bidPrice,
          myBids: [...(ses.myBids || []), bid],
        }));
      }
    },
    [bidPrice, selectedBidItem?._id, session]
  );

  const onBidItem = useCallback(async () => {
    if (
      selectedBidItem?.price !== undefined &&
      bidPrice < selectedBidItem?.price
    ) {
      alert("Bid price cannot lower than current price");
      return;
    }
    const result = await postMethod<Bid>({
      body: { item: selectedBidItem?._id, price: bidPrice },
    });
    result && updateBidForItem({ bid: result.data });
    result?.data && updateBidsSession(result?.data);
    deselectBidItem();
  }, [
    bidPrice,
    deselectBidItem,
    postMethod,
    selectedBidItem?._id,
    selectedBidItem?.price,
    updateBidForItem,
    updateBidsSession,
  ]);

  return (
    <BaseLayout>
      <div>There are currently {items?.length || 0} bid(s)</div>
      <List
        dataSource={items}
        renderItem={(item) => (
          <List.Item style={{ paddingLeft: 0 }}>
            <ItemCard item={item} onSelect={selectBidItem} />
          </List.Item>
        )}
      />
      {session.access_token && (
        <div>
          You can go to <Link href={"/myitem"}>My Item</Link> and create item to
          bid
        </div>
      )}
      <Modal
        title={`Bid for item ${selectedBidItem?.name}`}
        open={bidModal}
        onOk={onBidItem}
        onCancel={deselectBidItem}
        destroyOnClose
      >
        Price:
        <Input
          onChange={(e) => setBidPrice(parseFloat(e.target.value))}
          type={"number"}
        ></Input>
      </Modal>
    </BaseLayout>
  );
};

export default Bid;
