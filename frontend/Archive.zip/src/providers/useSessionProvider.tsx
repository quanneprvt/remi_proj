import React, {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { SessionType, Session, Bid, SocketMessage } from "@/app/interfaces";
import useApi from "@/hooks/useApi";
import { useRouter } from "next/router";
import { io, Socket } from "socket.io-client";
import useLogUser from "@/hooks/useLogUser";

interface Props {
  children: ReactNode;
}

const SessionContext = createContext<SessionType>({
  name: "",
  access_token: "",
  refresh_token: "",
  money: 0,
  setSession: (args) => args && args,
  socket: undefined,
  fetchNewAccessToken: () => {},
});

export const SessionProvider: React.FC<Props> = ({ children }) => {
  const [session, setSession] = useState<Session>({
    name: "",
    access_token: "",
    money: 0,
    refresh_token: "",
    myBids: [],
  });
  const { getMethod } = useApi("/api/users/me");
  const { getMethod: getBidsMethod } = useApi("/api/bids");
  const router = useRouter();
  const socket = useRef<Socket>();
  const { onLogout } = useLogUser();

  const fetchNewAccessToken = useCallback(async () => {
    const refreshToken = localStorage.getItem("token");
    try {
      const data = await fetch("/api/token", {
        method: "POST",
        body: JSON.stringify({ token: refreshToken }),
      });
      const result = await data.json();
      document.cookie = `token=${result.data.access_token};`;
    } catch {
      onLogout();
      return false;
    }
  }, [onLogout]);

  useEffect(() => {
    async function fetchUser() {
      const token = document.cookie.split(";")?.[0]?.split("=")?.[1];
      const refreshToken = localStorage.getItem("token") || "";
      if (token) {
        let result;
        result = await getMethod<{
          user: { name: string; money: number; message?: string };
        }>({ ignoreRefresh: true });
        if (result?.message === "Unauthorized") {
          await fetchNewAccessToken();
          result = await getMethod<{
            user: { name: string; money: number; message?: string };
          }>({ ignoreRefresh: true });
        }
        if (result && Boolean(result?.data?.user)) {
          const session = {
            name: result.data?.user.name,
            money: result.data?.user.money,
            access_token: token,
            refresh_token: refreshToken,
          } as Session;
          socket.current = io(`${process.env.NEXT_PUBLIC_SERVER_URL}`, {
            path: "/subscription/",
            auth: {
              token: session.access_token,
            },
          });
          setSession(session);
        }
      }
    }
    if (
      !router.pathname.includes("login") &&
      !router.pathname.includes("register")
    )
      fetchUser();
  }, [fetchNewAccessToken, getMethod, router]);

  useEffect(() => {
    async function fetchBids() {
      const token = document.cookie.split(";")?.[0]?.split("=")?.[1];
      if (token) {
        let result: any;
        result = await getBidsMethod<Bid[]>({ ignoreRefresh: true });
        if (result?.message === "Unauthorized") {
          await fetchNewAccessToken();
          result = await getBidsMethod<Bid[]>({ ignoreRefresh: true });
        }
        if (result?.data) {
          setSession((ses) => ({
            ...ses,
            myBids: result.data,
          }));
        }
      }
    }
    fetchBids();
  }, [fetchNewAccessToken, getBidsMethod]);

  useEffect(() => {
    socket?.current?.on("BID_SUCCESS", (message) => {
      const data = JSON.parse(message) as SocketMessage;
      if (data.item) {
        const bidItem = session.myBids?.find(
          (bid) => bid._id === data.item?._id
        );
        const isSuccess = data.item.currentBid === bidItem?._id;
        if (bidItem && !isSuccess)
          setSession((ses) => ({
            ...ses,
            money: ses.money + (data.bid?.price || 0),
          }));
      }
    });
    return () => {
      socket?.current?.off("BID_SUCCESS");
    };
  }, [session.myBids]);

  const value = useMemo(() => {
    return {
      ...session,
      setSession,
      fetchNewAccessToken,
      socket: socket.current,
    };
  }, [session, fetchNewAccessToken]);

  return (
    <SessionContext.Provider value={value}>{children}</SessionContext.Provider>
  );
};

export const useSessionProvider = () => {
  const value = useContext(SessionContext);
  return useMemo(() => value, [value]);
};
