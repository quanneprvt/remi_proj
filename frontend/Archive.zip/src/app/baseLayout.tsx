import useApi from "@/hooks/useApi";
import useLogUser from "@/hooks/useLogUser";
import { useSessionProvider } from "@/providers/useSessionProvider";
import { Avatar, Button, Input, Layout, Menu, Modal } from "antd";
import { Router, useRouter } from "next/router";
import { PropsWithChildren, useCallback, useState } from "react";
import { User } from "./interfaces";

const { Content, Footer, Header } = Layout;

const menuItems = [
  { key: "bid", label: "All Bid", ignoreAuth: true },
  { key: "mybid", label: "My Bid" },
  { key: "myitem", label: "My Item" },
];

const BaseLayout = (props: PropsWithChildren) => {
  const router = useRouter();
  const { access_token, money, name, setSession } = useSessionProvider();
  const [depositModal, setDepositModal] = useState<boolean>(false);
  const [depositMoney, setDepositMoney] = useState<number>(0);
  const { postMethod } = useApi("/api/users/deposit");
  const { onLogout } = useLogUser();

  const onDepositMoney = useCallback(async () => {
    const result = await postMethod<User>({
      body: { money: depositMoney },
    });
    result && setSession((ss) => ({ ...ss, money: result.data.money }));
    setDepositModal(false);
  }, [postMethod, depositMoney, setSession]);

  const onLogin = useCallback(() => {
    router.push({ pathname: "/login" });
  }, [router]);

  return (
    <Layout style={{ minHeight: "100vh" }}>
      <Header
        className="header"
        style={{
          display: "flex",
          width: "100%",
          justifyContent: "space-between",
        }}
      >
        <Menu
          theme="dark"
          mode="horizontal"
          defaultSelectedKeys={[router.asPath.split("/")[1]]}
          items={
            access_token
              ? menuItems.map((item) => ({ label: item.label, key: item.key }))
              : menuItems
                  .filter((item) => item.ignoreAuth)
                  .map((item) => ({ label: item.label, key: item.key }))
          }
          onClick={({ key }) => router.push(`/${key}`)}
          style={{ width: "100%" }}
        />
        <div
          style={{
            width: "60%",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: 10,
            justifyContent: "flex-end",
          }}
        >
          {access_token ? (
            <>
              <div style={{ color: "white", lineHeight: "20px" }}>
                My money: {money}
              </div>
              <Avatar style={{ color: "#f56a00", backgroundColor: "#fde3cf" }}>
                {name?.slice(0, 1).toUpperCase()}
              </Avatar>

              <Button type="primary" onClick={() => setDepositModal(true)}>
                Deposit
              </Button>
              <Button type="primary" onClick={onLogout}>
                Logout
              </Button>
            </>
          ) : (
            <Button type="primary" onClick={onLogin}>
              Login
            </Button>
          )}
        </div>
      </Header>
      <Content style={{ padding: "50px 50px" }}>{props.children}</Content>
      <Footer style={{ textAlign: "center", position: "sticky", bottom: 0 }}>
        Ant Design ©2023 Created by Ant UED
      </Footer>
      <Modal
        title={"Deposit money"}
        open={depositModal}
        onOk={onDepositMoney}
        onCancel={() => setDepositModal(false)}
        destroyOnClose
      >
        <Input
          onChange={(e) => setDepositMoney(parseFloat(e.target.value))}
          type={"number"}
        ></Input>
      </Modal>
    </Layout>
  );
};

export default BaseLayout;
