import { Socket } from "socket.io-client";

export interface Response {
  data?: unknown;
  message?: string;
}

export interface Session {
  name: string;
  money: number;
  access_token: string;
  refresh_token: string;
  myBids?: Bid[];
}

export interface SessionType extends Session {
  setSession: React.Dispatch<React.SetStateAction<Session>>;
  socket?: Socket;
  fetchNewAccessToken: () => void;
}

export enum ItemStatus {
  DRAFT = "DRAFT",
  OPEN = "OPEN",
  CLOSED = "CLOSED",
}

export interface User {
  _id: string;
  name: string;
  money: number;
}

export interface Item {
  _id: string;
  name: string;
  price: number;
  status: ItemStatus;
  currentBid?: Bid;
  publishTime?: Date;
}

export interface Bid {
  _id: string;
  item: Item;
  status: string;
  user: User;
  price: number;
}

export interface SocketMessage {
  item?: Item;
  bid?: Bid;
}
