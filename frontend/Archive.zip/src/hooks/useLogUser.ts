import { useRouter } from "next/router";
import { useSessionProvider } from "@/providers/useSessionProvider";
import { Session } from "../app/interfaces";
import { useCallback, useMemo } from "react";

const useLogUser = () => {
  const { setSession } = useSessionProvider();
  const router = useRouter();

  const onLoginSuccess = useCallback(
    (session: Session) => {
      setSession({ ...session } as Session);
      // save token
      document.cookie = `token=${session.access_token};`;
      localStorage.setItem("token", session.refresh_token);
    },
    [setSession]
  );

  const onLogout = useCallback(() => {
    document.cookie = "";
    localStorage.removeItem("token");
    setSession({ name: "", money: 0, access_token: "", refresh_token: "" });
    router.push("/login");
  }, [router, setSession]);

  return useMemo(
    () => ({
      onLoginSuccess,
      onLogout,
    }),
    [onLoginSuccess, onLogout]
  );
};

export default useLogUser;
