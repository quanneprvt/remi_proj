import React, { useEffect, useState } from "react";
import { Item } from "@/app/interfaces";
import { Button, Card } from "antd";
import { useSessionProvider } from "@/providers/useSessionProvider";
import { formatMiliSecond } from "@/utils/date";

interface ItemCardProps {
  item: Item;
  onSelect: (item: Item) => void;
}

const ItemCard: React.FC<ItemCardProps> = ({ item, onSelect }) => {
  const session = useSessionProvider();
  const [bidTimer, setBidTimer] = useState<number>(0);

  useEffect(() => {
    const timeBidConsumed =
      Date.now() - new Date(item.publishTime || Date.now()).getTime();
    const timeLeft =
      (parseFloat(process.env.NEXT_PUBLID_ITEM_BID_TIME + "") || 5) *
        60 *
        1000 -
      timeBidConsumed;
    setBidTimer(timeLeft);
  }, [item.publishTime]);

  useEffect(() => {
    const timer = setInterval(() => {
      setBidTimer((time) => {
        const left = Math.max(time - 1000, -1);
        if (left === -1) {
          clearInterval(timer);
          return 0;
        }
        return left;
      });
    }, 1000);
    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <Card
      title={item.name}
      style={{ width: "100%" }}
      actions={
        session.access_token && bidTimer > 0
          ? [
              <Button
                key="bid"
                type="primary"
                style={{ width: "50%" }}
                onClick={() => onSelect(item)}
              >
                Bid
              </Button>,
            ]
          : []
      }
    >
      <p>Base Price: {item.price}</p>
      <p>Current Bid: {item.currentBid?.price || 0}</p>
      <p>
        {bidTimer === 0
          ? "Bid End"
          : `Bid end in ${formatMiliSecond(bidTimer)}`}
      </p>
    </Card>
  );
};

export default ItemCard;
