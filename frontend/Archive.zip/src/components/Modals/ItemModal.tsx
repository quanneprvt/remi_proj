import React from "react";
import { Form, Input, Modal, Select } from "antd";

interface ItemModalProps {
  open: boolean;
  onConfirm: (data?: unknown) => void;
  onClose: () => void;
}

const ItemModal: React.FC<ItemModalProps> = ({ open, onClose, onConfirm }) => {
  return (
    <Modal
      title="Create Item To Bid"
      centered
      open={open}
      onCancel={onClose}
      okButtonProps={{ htmlType: "submit", form: "itemForm" }}
      destroyOnClose
    >
      <Form
        id="itemForm"
        name="basic"
        initialValues={{ remember: true }}
        onFinish={onConfirm}
        onFinishFailed={() => {}}
        autoComplete="off"
      >
        <Form.Item
          label="Name"
          name="name"
          rules={[{ required: true, message: "Please input item name!" }]}
          labelCol={{ span: 8 }}
          labelAlign={"left"}
        >
          <Input />
        </Form.Item>

        <Form.Item
          label="Price"
          name="price"
          rules={[{ required: true, message: "Please input item price!" }]}
          labelCol={{ span: 8 }}
          labelAlign={"left"}
        >
          <Input type={"number"} />
        </Form.Item>

        <Form.Item
          label="Status"
          name="status"
          rules={[{ required: true, message: "Please input item status!" }]}
          labelCol={{ span: 8 }}
          labelAlign={"left"}
          initialValue={"DRAFT"}
        >
          <Select disabled options={[{ value: "DRAFT", label: "Draft" }]} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ItemModal;
