export const colors = {
  default: {
    border: "rgba(0,0,0, 0.15)",
  },
};
